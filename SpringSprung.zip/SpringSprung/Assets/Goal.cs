﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnCollisionEnter2D(Collision2D collision){
		Debug.Log("Enter called.");
		Debug.Log(collision.gameObject.tag + " " + collision.otherCollider.tag);
		if(collision.gameObject.tag == "Ball"){

			Destroy(collision.gameObject);	
		}
	}
}
