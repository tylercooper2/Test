﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using System.Collections;

//  This script will be updated in Part 2 of this 2 part series.
public class MenuModalPanel : MonoBehaviour
{

    public Button backButton;
    public Button minimizeButton;
    public GameObject modalPanelObject;

    private static MenuModalPanel modalPanel;

    public static MenuModalPanel Instance()
    {
        if (!modalPanel)
        {
            modalPanel = FindObjectOfType(typeof(MenuModalPanel)) as MenuModalPanel;
            if (!modalPanel)
                Debug.LogError("There needs to be one active ModalPanel script on a GameObject in your scene.");
        }

        return modalPanel;
    }

    // Yes/No/Cancel: A string, a Yes event, a No event and Cancel event
    public void Choice(UnityAction yesEvent, UnityAction noEvent)
    {
        modalPanelObject.SetActive(true);

        backButton.onClick.RemoveAllListeners();
        backButton.onClick.AddListener(yesEvent);
        backButton.onClick.AddListener(ClosePanel);

        minimizeButton.onClick.RemoveAllListeners();
        minimizeButton.onClick.AddListener(noEvent);
        minimizeButton.onClick.AddListener(ClosePanel);



        backButton.gameObject.SetActive(true);
        minimizeButton.gameObject.SetActive(true);
        
    }

    public void ClosePanel()
    {
        modalPanelObject.SetActive(false);
    }
}