﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class TestModalWindow : MonoBehaviour
{
    public Sprite icon;
    public Text levelNumber;
    public Sprite stars; 

    private ModalPanel modalPanel;
    private DisplayManager displayManager;
    private bool completed; 

    //private UnityAction myYesAction;
    //private UnityAction myNoAction;

   

    void Awake ()
    {
        modalPanel = ModalPanel.Instance();
        displayManager = DisplayManager.Instance();
    }
	
    //When the user completes a level this will call the choice function to bring up the modal window for the level completed
    //Bool completed is used to differentiate the override choice functions 
    public void LevelComplete()
    {
        completed = false; 
        modalPanel.Choice("Level Complete!", icon, NextLevel, ReturnToLevelSelect, levelNumber, completed);
    }

    //When the user clicks a level on the level select screen, calls the choice function to bring up the modal window with the level information
    //Level number is the number of the level from the text of the button that is clicked
    //Icon is the level preview image 
    public void TestYNI()
    {
        modalPanel.Choice("Level: ", icon, TestYesFunction, TestNoFunction, levelNumber);
    }

    //If the user chooses to play the selected level 
    //Gets the level number of the button that was clicked
    //Loads the level using the level number of the button + 2 to load the correct scene
    void TestYesFunction()
    {
        int level = int.Parse(levelNumber.text);
        displayManager.DisplayMessage("Yes");
        Application.LoadLevel(level + 2);
    }

    //If the user does not want to play the level
    //Does nothing and the modal window is minimized
    void TestNoFunction()
    {
        displayManager.DisplayMessage("No");
        //Application.LoadLevel(1);
    }

    //When the user completes a level and chooses to return to the level select menu
    //Loads the level select scene 
    void ReturnToLevelSelect()
    {
        displayManager.DisplayMessage("No");
        Application.LoadLevel(1); 
    }

    //If the user completes a level and chooses to go on to the next level 
    //Loads the next level scene 
    void NextLevel()
    {
        int level = int.Parse(levelNumber.text);
        displayManager.DisplayMessage("Yes");
        Application.LoadLevel(level + 1);
    }

}
