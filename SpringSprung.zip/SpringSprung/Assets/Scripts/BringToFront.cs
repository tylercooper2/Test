﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BringToFront : MonoBehaviour {

	void OnEnable ()
    {
        transform.SetAsLastSibling();  //Makes this the last thing to be drawn so it will draw on top of everything
    }
}
