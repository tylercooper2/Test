﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using System.Collections;

//  This script will be updated in Part 2 of this 2 part series.
public class TestModaMenuPanel : MonoBehaviour
{
    private MenuModalPanel modalPanel;
    private DisplayManager displayManager;

    private UnityAction myQuitAction;
    private UnityAction myMinimizeAction;
    private UnityAction myCancelAction;

    void Awake()
    {
        modalPanel = MenuModalPanel.Instance();
        displayManager = DisplayManager.Instance();

        myQuitAction = new UnityAction(quitFunction);
        myMinimizeAction = new UnityAction(minimizeFunction);
  
    }

    //  Send to the Modal Panel to set up the Buttons and Functions to call
    public void TestYNC()
    {
        modalPanel.Choice(quitFunction, minimizeFunction);
        //      modalPanel.Choice ("Would you like a poke in the eye?\nHow about with a sharp stick?", myYesAction, myNoAction, myCancelAction);
    }

    //  These are wrapped into UnityActions
    void quitFunction()
    {
        Application.LoadLevel(1);
        displayManager.DisplayMessage("");
    }

    void minimizeFunction()
    {
        modalPanel.ClosePanel(); 
        displayManager.DisplayMessage("");
    }

   
}