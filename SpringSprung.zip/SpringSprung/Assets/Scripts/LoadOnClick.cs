﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadOnClick : MonoBehaviour {

    public GameObject loadingImage;



	public void LoadScene(int level)
    {
        //Uncomment to get a loading screen between the scenes
        //For now since there is no loading time, leave commented 
        /*
        if(level != 3)
        {
            loadingImage.SetActive(true);

        }
        */
        Application.LoadLevel(level); 
    }
}
