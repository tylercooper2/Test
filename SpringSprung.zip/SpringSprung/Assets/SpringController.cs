﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpringController : MonoBehaviour {

	//original scale of spring
	Vector3 orgScale;
	//magnitude of force 
	private int magnitude;
	//force added to object hitting spring
	private Vector3 force;
	//flag for mouse held down
	bool flag;

	//initialize 
	void Start () {
		//mouse is not held down
		flag = false;
		//start with 0 magnitude for force
		magnitude = 0;
		//save original scale of spring
		orgScale = transform.localScale;
		
	}
	
	// Update is called once per frame
	void Update () {
		//if spring was clicked and held
		if (flag == true){
			//compress the spring while holding mouse down and increase magnitude
			if(transform.localScale.y > (orgScale.y*0.25)){
				transform.localScale += new Vector3(0, -0.01F, 0);
				magnitude+=3;
			}
		//if spring was let go 	
		}else{
			//decompress the spring by a factor of 0.5 in the y axis
			if(transform.localScale.y < orgScale.y && transform.localScale.y < (orgScale.y-0.5)){
				transform.localScale += new Vector3(0, 0.5F, 0);
			//if the difference between the original scale and current scale is less than 0.5, then transform to original scale and reset magnitude
			}else{
				transform.localScale = orgScale;
				magnitude = 0;
			}
			//decrease magnitude while decompressing spring
			magnitude-=1;
		}
	}

	//add force on collision
	void OnCollisionEnter2D(Collision2D collision){
		Debug.Log("Enter called.");
		Debug.Log(collision.collider.name + " " + collision.otherCollider.name);
		//if mouse is held down 
		if(Input.GetMouseButton(0)){
			//do nothing
		//else if mouse is let go		
		}else{
			if (collision.otherCollider.tag == "Spring"){
				Debug.Log("Spring hit.");
				Debug.Log(magnitude);
				//reset to orignal scale
				transform.localScale = orgScale;
				//calculate force
				force = transform.position - collision.transform.position;
				force.Normalize ();
				//add force
				collision.collider.GetComponent<Rigidbody2D>().AddForce (-force * magnitude);
				//reset magnitude
				magnitude = 0;	
			}
		}
	}
	//set mousebutton held down to true
	void OnMouseDown(){
		flag = true;
	}
	//set mousebutton held down to false
	void OnMouseUp(){
		flag = false;
	}
	

	
}
