﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class TestModalWindow : MonoBehaviour
{
    public Sprite icon;
    public Text levelNumber;

    private ModalPanel modalPanel;
    private DisplayManager displayManager;

    //private UnityAction myYesAction;
    //private UnityAction myNoAction;

   

    void Awake ()
    {
        modalPanel = ModalPanel.Instance();
        displayManager = DisplayManager.Instance();

        //myYesAction = new UnityAction(TestYesFunction);
        //myNoAction = new UnityAction(TestNoFunction);

        

    }
	/*
    public void TestYN () 
    {
        modalPanel.Choice("Level: ", TestYesFunction, TestNoFunction); 
    }
    */
    public void TestYNI()
    {
        modalPanel.Choice("Level: ", icon, TestYesFunction, TestNoFunction, levelNumber);
    }

    void TestYesFunction()
    {
        int level = int.Parse(levelNumber.text);
        displayManager.DisplayMessage("Yes");
        Application.LoadLevel(level + 1);
    }

    void TestNoFunction()
    {
        displayManager.DisplayMessage("No");
    }


}
