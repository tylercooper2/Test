﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events; 

public class ModalPanel : MonoBehaviour
{
    public Text question;
    public Image iconImage;
    public Button yesButton;
    public Button noButton;
    public GameObject modalPanelObject;

    public Text levelNumber; 



    //Take a static reference to a modal panel, ask for an instance of the panel, find it in the game and then return it
    //Calling modal panel reference will reference to this script 
    private static ModalPanel modalPanel;

    public static ModalPanel Instance()
    {
        if (!modalPanel)
        {
            modalPanel = FindObjectOfType(typeof(ModalPanel)) as ModalPanel;
            if (!modalPanel)
                Debug.LogError("There needs to be one active ModalPanel script on a GameObject in your scene.");
        }

        return modalPanel;
    }
    /*
    //Yes / No: A string, aa yes event, a no event 
    public void Choice (string question, UnityAction yesEvent, UnityAction noEvent)
    {
        modalPanelObject.SetActive(true);
        yesButton.onClick.RemoveAllListeners();
        yesButton.onClick.AddListener(yesEvent);
        yesButton.onClick.AddListener(closePanel);

        
        noButton.onClick.RemoveAllListeners();
        noButton.onClick.AddListener(noEvent);
        noButton.onClick.AddListener(closePanel);

        this.question.text = question;

        this.iconImage.gameObject.SetActive(true);
        yesButton.gameObject.SetActive(true);
        noButton.gameObject.SetActive(true); 


    }
    */

    public void Choice(string question, Sprite iconImage, UnityAction yesEvent, UnityAction noEvent, Text levelNumber, bool completed)
    {
        modalPanelObject.SetActive(true);
        yesButton.onClick.RemoveAllListeners();
        yesButton.onClick.AddListener(yesEvent);
        yesButton.onClick.AddListener(closePanel);


        noButton.onClick.RemoveAllListeners();
        noButton.onClick.AddListener(noEvent);
        noButton.onClick.AddListener(closePanel);

        this.question.text = question;
        this.iconImage.sprite = iconImage;
        this.levelNumber.text = levelNumber.text;

        this.iconImage.gameObject.SetActive(true);
        yesButton.gameObject.SetActive(true);
        noButton.gameObject.SetActive(true);
    }

    //Brings up the modal window, Question displays "Level: ", iconImage is the level preview, yes event and no event are the events for the buttons
    //LevelNumber holds which level button was pressed, will hold 1 for level 1, ect. 
    public void Choice(string question, Sprite iconImage, UnityAction yesEvent, UnityAction noEvent,  Text levelNumber)
    {
        modalPanelObject.SetActive(true);
        yesButton.onClick.RemoveAllListeners();
        yesButton.onClick.AddListener(yesEvent);
        yesButton.onClick.AddListener(closePanel);


        noButton.onClick.RemoveAllListeners();
        noButton.onClick.AddListener(noEvent);
        noButton.onClick.AddListener(closePanel);

        this.question.text = question + levelNumber.text;
        this.iconImage.sprite = iconImage;
        this.levelNumber.text = levelNumber.text; 

        this.iconImage.gameObject.SetActive(true);
        yesButton.gameObject.SetActive(true);
        noButton.gameObject.SetActive(true);


    }

    void closePanel()
    {
        modalPanelObject.SetActive(false);
    }

}
